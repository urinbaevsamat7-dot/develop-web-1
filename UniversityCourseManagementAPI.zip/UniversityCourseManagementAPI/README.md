# University Course Management API

Учебный REST Web API для задания CSE5032 «Разработка веб-сервисов» (модули 1–4). Реализован на ASP.NET Core 8, Entity Framework Core и SQL Server.

## Реализовано

- CRUD для студентов, преподавателей и курсов.
- Запись студента на курс, список записей, получение по ID, изменение оценки (`PATCH`) и удаление записи.
- Проверка существования студента, курса и преподавателя.
- Запрет повторной записи на тот же курс (проверка в сервисе и уникальный индекс БД).
- Фильтрация курсов по названию, преподавателю и диапазону кредитов.
- `ApplicationDbContext`, `DbSet`, связи EF Core, Fluent API и Data Annotations.
- Repository Pattern, сервисный слой и Dependency Injection (`Scoped`).
- DTO и AutoMapper `MappingProfile`.
- Единый `ReturnResult<T>` для ответов, корректные HTTP-коды, централизованная обработка исключений.
- `ILogger` для ключевых операций и ошибок.
- Swagger/OpenAPI.
- Примеры тестовых данных при первом старте.

## Требования

- Windows 10/11
- .NET 8 SDK
- SQL Server (Developer/Express) и доступный экземпляр SQL Server
- Visual Studio 2022 или VS Code (необязательно)

## Быстрый запуск в Windows

1. Установите **.NET 8 SDK** и SQL Server Express/Developer, если они ещё не установлены.
2. Проверьте имя SQL Server instance в SSMS. По умолчанию строка подключения использует `localhost`.
3. Откройте `src/UniversityApi/appsettings.json`. При необходимости измените `DefaultConnection`:
   - обычный локальный экземпляр: `Server=localhost;Database=UniversityCourseManagementDb;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true`
   - SQL Express: `Server=localhost\\SQLEXPRESS;Database=UniversityCourseManagementDb;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true`
   - LocalDB: `Server=(localdb)\\MSSQLLocalDB;Database=UniversityCourseManagementDb;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=true`
4. В PowerShell перейдите в папку проекта (где `.sln`) и выполните:

   ```powershell
   dotnet restore
   dotnet build
   dotnet run --project .\src\UniversityApi\UniversityApi.csproj
   ```

5. Откройте URL, показанный в консоли, добавив `/swagger`. Если запускается профиль HTTPS, Swagger обычно доступен по `https://localhost:xxxx/swagger`.
6. При первом запуске приложение создаёт схему через `EnsureCreated()` и добавляет демо-данные. Если база недоступна, ошибка попадёт в лог: исправьте строку подключения и перезапустите приложение.

> Для учебной работы используется `EnsureCreated`, чтобы запуск был проще. Если позже понадобится менять схему, добавьте EF Core migrations; `EnsureCreated` не заменяет миграции для развиваемой production-базы.

## Основные endpoints

| Метод | Endpoint | Назначение |
|---|---|---|
| GET | `/api/students` | Список студентов |
| GET | `/api/students/{id}` | Студент по ID |
| GET | `/api/students/{id}/courses` | Студент и его курсы |
| POST | `/api/students` | Создать студента |
| PUT | `/api/students/{id}` | Изменить студента |
| DELETE | `/api/students/{id}` | Удалить студента |
| GET/POST/PUT/DELETE | `/api/teachers[/{id}]` | CRUD преподавателей |
| GET | `/api/courses?name=web&teacherId=1&minCredits=2&maxCredits=6` | Список/фильтрация курсов |
| GET/POST/PUT/DELETE | `/api/courses[/{id}]` | CRUD курсов |
| GET | `/api/enrollments` | Все записи |
| GET | `/api/enrollments/{id}` | Запись по ID |
| POST | `/api/enrollments` | Записать студента на курс |
| PATCH | `/api/enrollments/{id}/grade` | Изменить оценку |
| DELETE | `/api/enrollments/{id}` | Удалить запись |

Все ответы API используют envelope: `statusCode`, `isSuccess`, `result`, `errorCode`, `errorMessage`, `traceId`. Ошибки валидации `[ApiController]` автоматически возвращаются как HTTP 400 в стандартном ASP.NET Core validation format; бизнес-ошибки используют `ReturnResult<T>`.

## Примеры запросов для Swagger

### Создать студента — `POST /api/students`

```json
{
  "firstName": "Erлан",
  "lastName": "Student",
  "email": "erlan.student@example.com",
  "birthDate": "2005-05-07T00:00:00"
}
```

### Создать преподавателя — `POST /api/teachers`

```json
{
  "firstName": "Aida",
  "lastName": "Teacher",
  "email": "aida.teacher@example.com",
  "department": "Software Engineering"
}
```

### Создать курс — `POST /api/courses`

```json
{
  "name": "Secure Web Development",
  "description": "API security basics",
  "credits": 5,
  "teacherId": 1
}
```

### Записать студента на курс — `POST /api/enrollments`

```json
{
  "studentId": 1,
  "courseId": 1
}
```

### Изменить оценку — `PATCH /api/enrollments/1/grade`

```json
{
  "grade": 95
}
```

### Ожидаемые сценарии

1. `GET /api/students` — список студентов.
2. `POST /api/students` — создать нового студента; ответ 201.
3. `GET /api/students/{newId}` — получить созданного студента.
4. `PUT /api/students/{newId}` — обновить студента.
5. Создать преподавателя, затем курс с его `teacherId`.
6. Записать существующего студента на существующий курс.
7. Повторить тот же `POST /api/enrollments` — ответ 409.
8. `GET /api/students/{id}/courses` — показать курсы студента.
9. `GET /api/courses?minCredits=4&maxCredits=5` — фильтрация.
10. Удалить/изменить объект.
11. Запросить неизвестный ID — ответ 404.
12. Отправить некорректный email или credits вне диапазона — ответ 400.
13. Проверить `Information`, `Warning` и `Error` в консоли приложения.

## Схема базы данных

- `Students (Id PK, FirstName, LastName, Email UNIQUE, BirthDate, CreatedAt)`
- `Teachers (Id PK, FirstName, LastName, Email UNIQUE, Department)`
- `Courses (Id PK, TeacherId FK -> Teachers.Id, Name, Description, Credits, CreatedAt)`
- `Enrollments (Id PK, StudentId FK -> Students.Id, CourseId FK -> Courses.Id, EnrollmentDate, Grade, UNIQUE(StudentId, CourseId))`

## Файлы для сдачи

- `src/UniversityApi/` — исходный код API.
- `database/create-and-seed.sql` — скрипт создания таблиц и тестовых данных для SQL Server.
- `docs/architecture.md` — схема архитектуры.
- `README.md` — запуск, endpoints и сценарии проверки.
- `UniversityCourseManagementAPI.sln` — solution для Visual Studio.

## Важно перед сдачей

Архив содержит исходный проект и SQL-скрипт, но его нужно собрать и реально запустить на компьютере с .NET 8 SDK и SQL Server. Swagger и HTTP-сценарии проверьте локально; в текущей среде .NET SDK не установлен, поэтому здесь сборка не выполнялась.

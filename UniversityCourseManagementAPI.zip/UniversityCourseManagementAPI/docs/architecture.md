# Architecture

```mermaid
flowchart TD
    Client[Swagger / Postman / Client] -->|HTTP JSON| Controller[API Controllers]
    Controller --> Service[Services / Business Rules]
    Service --> Repository[Repository Interfaces and Implementations]
    Repository --> EF[Entity Framework Core]
    EF --> DB[(SQL Server Database)]
    Controller --> Result[ReturnResult<T>]
    Middleware[Exception Handling Middleware] -. wraps requests .-> Controller
    EF -. logging via ILogger .-> Logs[Application Logs]
```

- **Controllers**: HTTP routing, status codes, request/response boundary.
- **Services**: business rules, duplicate enrollment checks and existence validation.
- **Repositories**: database queries through EF Core, no in-memory data store.
- **ApplicationDbContext**: entity relationships, unique constraints and indexes.
- **DTO + AutoMapper**: API contracts are separate from database entities.
- **ReturnResult<T>**: consistent response envelope including trace identifier.
- **Middleware**: unexpected exceptions are logged; internal exception details are not exposed.

/*
  Optional SQL Server setup script. The application can also create the schema with
  EF Core EnsureCreated on first run. Run this script only if you want to create and
  populate the database manually. It is safe to run on a fresh SQL Server instance.
*/
IF DB_ID(N'UniversityCourseManagementDb') IS NULL
    CREATE DATABASE UniversityCourseManagementDb;
GO
USE UniversityCourseManagementDb;
GO

IF OBJECT_ID('dbo.Teachers', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Teachers (
        Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        FirstName NVARCHAR(80) NOT NULL,
        LastName NVARCHAR(80) NOT NULL,
        Email NVARCHAR(160) NOT NULL,
        Department NVARCHAR(100) NOT NULL
    );
    CREATE UNIQUE INDEX IX_Teachers_Email ON dbo.Teachers(Email);
END
GO
IF OBJECT_ID('dbo.Students', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Students (
        Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        FirstName NVARCHAR(80) NOT NULL,
        LastName NVARCHAR(80) NOT NULL,
        Email NVARCHAR(160) NOT NULL,
        BirthDate DATETIME2 NOT NULL,
        CreatedAt DATETIME2 NOT NULL
    );
    CREATE UNIQUE INDEX IX_Students_Email ON dbo.Students(Email);
END
GO
IF OBJECT_ID('dbo.Courses', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Courses (
        Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        Name NVARCHAR(120) NOT NULL,
        Description NVARCHAR(1000) NULL,
        Credits INT NOT NULL,
        TeacherId INT NOT NULL,
        CreatedAt DATETIME2 NOT NULL,
        CONSTRAINT FK_Courses_Teachers_TeacherId FOREIGN KEY (TeacherId) REFERENCES dbo.Teachers(Id)
    );
END
GO
IF OBJECT_ID('dbo.Enrollments', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.Enrollments (
        Id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        StudentId INT NOT NULL,
        CourseId INT NOT NULL,
        EnrollmentDate DATETIME2 NOT NULL,
        Grade DECIMAL(5,2) NULL,
        CONSTRAINT FK_Enrollments_Students_StudentId FOREIGN KEY (StudentId) REFERENCES dbo.Students(Id) ON DELETE CASCADE,
        CONSTRAINT FK_Enrollments_Courses_CourseId FOREIGN KEY (CourseId) REFERENCES dbo.Courses(Id) ON DELETE CASCADE
    );
    CREATE UNIQUE INDEX IX_Enrollments_StudentId_CourseId ON dbo.Enrollments(StudentId, CourseId);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Teachers WHERE Email='a.sadykova@university.example')
    INSERT dbo.Teachers(FirstName, LastName, Email, Department)
    VALUES ('Aigerim','Sadykova','a.sadykova@university.example','Software Engineering');
IF NOT EXISTS (SELECT 1 FROM dbo.Teachers WHERE Email='d.omarov@university.example')
    INSERT dbo.Teachers(FirstName, LastName, Email, Department)
    VALUES ('Daniyar','Omarov','d.omarov@university.example','Information Security');
IF NOT EXISTS (SELECT 1 FROM dbo.Students WHERE Email='alex.smith@example.com')
    INSERT dbo.Students(FirstName, LastName, Email, BirthDate, CreatedAt)
    VALUES ('Alex','Smith','alex.smith@example.com','2003-05-12',SYSUTCDATETIME());
IF NOT EXISTS (SELECT 1 FROM dbo.Students WHERE Email='dana.kim@example.com')
    INSERT dbo.Students(FirstName, LastName, Email, BirthDate, CreatedAt)
    VALUES ('Dana','Kim','dana.kim@example.com','2004-02-03',SYSUTCDATETIME());
IF NOT EXISTS (SELECT 1 FROM dbo.Courses WHERE Name='Web Services Development')
    INSERT dbo.Courses(Name,Description,Credits,TeacherId,CreatedAt)
    SELECT 'Web Services Development','REST API design and implementation.',5,Id,SYSUTCDATETIME()
    FROM dbo.Teachers WHERE Email='a.sadykova@university.example';
IF NOT EXISTS (SELECT 1 FROM dbo.Courses WHERE Name='Application Security')
    INSERT dbo.Courses(Name,Description,Credits,TeacherId,CreatedAt)
    SELECT 'Application Security','Secure application development fundamentals.',4,Id,SYSUTCDATETIME()
    FROM dbo.Teachers WHERE Email='d.omarov@university.example';
IF NOT EXISTS (
    SELECT 1 FROM dbo.Enrollments e
    JOIN dbo.Students s ON s.Id=e.StudentId
    JOIN dbo.Courses c ON c.Id=e.CourseId
    WHERE s.Email='alex.smith@example.com' AND c.Name='Web Services Development'
)
    INSERT dbo.Enrollments(StudentId,CourseId,EnrollmentDate,Grade)
    SELECT s.Id,c.Id,SYSUTCDATETIME(),92
    FROM dbo.Students s CROSS JOIN dbo.Courses c
    WHERE s.Email='alex.smith@example.com' AND c.Name='Web Services Development';
GO

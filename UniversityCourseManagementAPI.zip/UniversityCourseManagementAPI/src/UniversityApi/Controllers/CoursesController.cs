using Microsoft.AspNetCore.Mvc;
using UniversityApi.Common;
using UniversityApi.DTO.Courses;
using UniversityApi.Services;

namespace UniversityApi.Controllers;

[Route("api/[controller]")]
public class CoursesController(ICourseService service) : ApiControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? name, [FromQuery] int? teacherId,
        [FromQuery] int? minCredits, [FromQuery] int? maxCredits, CancellationToken ct)
    {
        if (minCredits < 0 || maxCredits < 0 || (minCredits.HasValue && maxCredits.HasValue && minCredits > maxCredits))
            return ErrorResult<List<CourseDto>>(400, "INVALID_FILTER", "Credit filters are invalid.");
        var result = name is not null || teacherId.HasValue || minCredits.HasValue || maxCredits.HasValue
            ? await service.SearchAsync(name, teacherId, minCredits, maxCredits, ct)
            : await service.GetAllAsync(ct);
        return OkResult(result);
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var result = await service.GetByIdAsync(id, ct);
        return result is null ? ErrorResult<CourseDto>(404, "COURSE_NOT_FOUND", "Course not found.") : OkResult(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CourseCreateDto dto, CancellationToken ct)
    {
        var (value, error) = await service.CreateAsync(dto, ct);
        if (error == "TEACHER_NOT_FOUND") return ErrorResult<CourseDto>(404, error, "Teacher not found.");
        return StatusCode(201, ReturnResult<CourseDto>.Success(value, 201, HttpContext.TraceIdentifier));
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] CourseUpdateDto dto, CancellationToken ct)
    {
        var (value, error) = await service.UpdateAsync(id, dto, ct);
        if (error == "NOT_FOUND") return ErrorResult<CourseDto>(404, "COURSE_NOT_FOUND", "Course not found.");
        if (error == "TEACHER_NOT_FOUND") return ErrorResult<CourseDto>(404, error, "Teacher not found.");
        return OkResult(value);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct) =>
        await service.DeleteAsync(id, ct) ? OkResult(new { message = "Course deleted." }) :
            ErrorResult<object>(404, "COURSE_NOT_FOUND", "Course not found.");
}

using Microsoft.AspNetCore.Mvc;
using UniversityApi.Common;
using UniversityApi.DTO.Students;
using UniversityApi.Services;

namespace UniversityApi.Controllers;

[Route("api/[controller]")]
public class StudentsController(IStudentService service, ILogger<StudentsController> logger) : ApiControllerBase
{
    [HttpGet]
    [ProducesResponseType(typeof(ReturnResult<List<StudentDto>>), 200)]
    public async Task<IActionResult> GetAll(CancellationToken ct) => OkResult(await service.GetAllAsync(ct));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var result = await service.GetByIdAsync(id, ct);
        return result is null ? ErrorResult<StudentDto>(404, "STUDENT_NOT_FOUND", "Student not found.") : OkResult(result);
    }

    [HttpGet("{id:int}/courses")]
    public async Task<IActionResult> GetWithCourses(int id, CancellationToken ct)
    {
        var result = await service.GetWithCoursesAsync(id, ct);
        return result is null ? ErrorResult<StudentWithCoursesDto>(404, "STUDENT_NOT_FOUND", "Student not found.") : OkResult(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] StudentCreateDto dto, CancellationToken ct)
    {
        var (value, error) = await service.CreateAsync(dto, ct);
        if (error == "EMAIL_ALREADY_EXISTS") return ErrorResult<StudentDto>(409, error, "A student with this email already exists.");
        return StatusCode(201, ReturnResult<StudentDto>.Success(value, 201, HttpContext.TraceIdentifier));
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, [FromBody] StudentUpdateDto dto, CancellationToken ct)
    {
        var (value, error) = await service.UpdateAsync(id, dto, ct);
        if (error == "NOT_FOUND") return ErrorResult<StudentDto>(404, "STUDENT_NOT_FOUND", "Student not found.");
        if (error == "EMAIL_ALREADY_EXISTS") return ErrorResult<StudentDto>(409, error, "A student with this email already exists.");
        return OkResult(value);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct) =>
        await service.DeleteAsync(id, ct) ? OkResult(new { message = "Student deleted." }) :
            ErrorResult<object>(404, "STUDENT_NOT_FOUND", "Student not found.");
}

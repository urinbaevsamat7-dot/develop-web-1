using Microsoft.AspNetCore.Mvc;
using UniversityApi.Common;
using UniversityApi.DTO.Enrollments;
using UniversityApi.Services;

namespace UniversityApi.Controllers;

[Route("api/[controller]")]
public class EnrollmentsController(IEnrollmentService service) : ApiControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll(CancellationToken ct) => OkResult(await service.GetAllAsync(ct));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var result = await service.GetByIdAsync(id, ct);
        return result is null ? ErrorResult<EnrollmentDto>(404, "ENROLLMENT_NOT_FOUND", "Enrollment not found.") : OkResult(result);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] EnrollmentCreateDto dto, CancellationToken ct)
    {
        var (value, error) = await service.CreateAsync(dto, ct);
        return error switch
        {
            "STUDENT_NOT_FOUND" => ErrorResult<EnrollmentDto>(404, error, "Student not found."),
            "COURSE_NOT_FOUND" => ErrorResult<EnrollmentDto>(404, error, "Course not found."),
            "ENROLLMENT_ALREADY_EXISTS" => ErrorResult<EnrollmentDto>(409, error, "This student is already enrolled in this course."),
            _ => StatusCode(201, ReturnResult<EnrollmentDto>.Success(value, 201, HttpContext.TraceIdentifier))
        };
    }

    [HttpPatch("{id:int}/grade")]
    public async Task<IActionResult> UpdateGrade(int id, [FromBody] EnrollmentGradeUpdateDto dto, CancellationToken ct)
    {
        var (value, error) = await service.UpdateGradeAsync(id, dto, ct);
        return error == "NOT_FOUND"
            ? ErrorResult<EnrollmentDto>(404, "ENROLLMENT_NOT_FOUND", "Enrollment not found.")
            : OkResult(value);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct) =>
        await service.DeleteAsync(id, ct) ? OkResult(new { message = "Enrollment deleted." }) :
            ErrorResult<object>(404, "ENROLLMENT_NOT_FOUND", "Enrollment not found.");
}

using Microsoft.EntityFrameworkCore;
using UniversityApi.Models;

namespace UniversityApi.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(ApplicationDbContext db)
    {
        if (await db.Teachers.AnyAsync()) return;

        var teachers = new[]
        {
            new Teacher { FirstName = "Aigerim", LastName = "Sadykova", Email = "a.sadykova@university.example", Department = "Software Engineering" },
            new Teacher { FirstName = "Daniyar", LastName = "Omarov", Email = "d.omarov@university.example", Department = "Information Security" }
        };
        db.Teachers.AddRange(teachers);
        await db.SaveChangesAsync();

        var students = new[]
        {
            new Student { FirstName = "Alex", LastName = "Smith", Email = "alex.smith@example.com", BirthDate = new DateTime(2003, 5, 12), CreatedAt = DateTime.UtcNow },
            new Student { FirstName = "Dana", LastName = "Kim", Email = "dana.kim@example.com", BirthDate = new DateTime(2004, 2, 3), CreatedAt = DateTime.UtcNow }
        };
        db.Students.AddRange(students);
        await db.SaveChangesAsync();

        var courses = new[]
        {
            new Course { Name = "Web Services Development", Description = "REST API design and implementation.", Credits = 5, TeacherId = teachers[0].Id, CreatedAt = DateTime.UtcNow },
            new Course { Name = "Application Security", Description = "Secure application development fundamentals.", Credits = 4, TeacherId = teachers[1].Id, CreatedAt = DateTime.UtcNow }
        };
        db.Courses.AddRange(courses);
        await db.SaveChangesAsync();

        db.Enrollments.Add(new Enrollment { StudentId = students[0].Id, CourseId = courses[0].Id, EnrollmentDate = DateTime.UtcNow, Grade = 92 });
        await db.SaveChangesAsync();
    }
}

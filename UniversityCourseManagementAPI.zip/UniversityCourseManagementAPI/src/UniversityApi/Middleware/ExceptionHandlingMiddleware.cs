using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using UniversityApi.Common;

namespace UniversityApi.Middleware;

public sealed class ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
{
    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await next(context);
        }
        catch (DbUpdateException ex)
        {
            logger.LogError(ex, "Database update failed. TraceId: {TraceId}", context.TraceIdentifier);
            context.Response.StatusCode = StatusCodes.Status409Conflict;
            context.Response.ContentType = "application/json";
            var payload = ReturnResult<object>.Failure(409, "DATA_CONFLICT",
                "The operation conflicts with existing data or database constraints.", context.TraceIdentifier);
            await context.Response.WriteAsync(JsonSerializer.Serialize(payload));
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Unhandled application error. TraceId: {TraceId}", context.TraceIdentifier);
            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            context.Response.ContentType = "application/json";
            var payload = ReturnResult<object>.Failure(500, "INTERNAL_SERVER_ERROR",
                "An unexpected error occurred.", context.TraceIdentifier);
            await context.Response.WriteAsync(JsonSerializer.Serialize(payload));
        }
    }
}

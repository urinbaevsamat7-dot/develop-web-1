using Microsoft.EntityFrameworkCore;
using UniversityApi.Data;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Repositories.Implementations;

public sealed class StudentRepository(ApplicationDbContext db) : Repository<Student>(db), IStudentRepository
{
    public Task<Student?> GetWithCoursesAsync(int id, CancellationToken cancellationToken = default) =>
        Db.Students.AsNoTracking().Include(s => s.Enrollments).ThenInclude(e => e.Course)
            .FirstOrDefaultAsync(s => s.Id == id, cancellationToken);
    public Task<bool> EmailExistsAsync(string email, int? exceptId = null, CancellationToken cancellationToken = default) =>
        Db.Students.AnyAsync(s => s.Email == email && (!exceptId.HasValue || s.Id != exceptId), cancellationToken);
}
public sealed class TeacherRepository(ApplicationDbContext db) : Repository<Teacher>(db), ITeacherRepository
{
    public Task<bool> EmailExistsAsync(string email, int? exceptId = null, CancellationToken cancellationToken = default) =>
        Db.Teachers.AnyAsync(s => s.Email == email && (!exceptId.HasValue || s.Id != exceptId), cancellationToken);
}
public sealed class CourseRepository(ApplicationDbContext db) : Repository<Course>(db), ICourseRepository
{
    public override Task<List<Course>> GetAllAsync(CancellationToken cancellationToken = default) =>
        Db.Courses.AsNoTracking().Include(c => c.Teacher).ToListAsync(cancellationToken);
    public override Task<Course?> GetByIdAsync(int id, CancellationToken cancellationToken = default) =>
        Db.Courses.Include(c => c.Teacher).FirstOrDefaultAsync(c => c.Id == id, cancellationToken);
    public Task<bool> TeacherExistsAsync(int teacherId, CancellationToken cancellationToken = default) =>
        Db.Teachers.AnyAsync(t => t.Id == teacherId, cancellationToken);
    public Task<List<Course>> SearchAsync(string? name, int? teacherId, int? minCredits, int? maxCredits, CancellationToken cancellationToken = default)
    {
        var query = Db.Courses.AsNoTracking().Include(c => c.Teacher).AsQueryable();
        if (!string.IsNullOrWhiteSpace(name)) query = query.Where(c => c.Name.Contains(name));
        if (teacherId.HasValue) query = query.Where(c => c.TeacherId == teacherId.Value);
        if (minCredits.HasValue) query = query.Where(c => c.Credits >= minCredits.Value);
        if (maxCredits.HasValue) query = query.Where(c => c.Credits <= maxCredits.Value);
        return query.OrderBy(c => c.Name).ToListAsync(cancellationToken);
    }
}
public sealed class EnrollmentRepository(ApplicationDbContext db) : Repository<Enrollment>(db), IEnrollmentRepository
{
    public override Task<List<Enrollment>> GetAllAsync(CancellationToken cancellationToken = default) =>
        Db.Enrollments.AsNoTracking().Include(e => e.Student).Include(e => e.Course).ToListAsync(cancellationToken);
    public override Task<Enrollment?> GetByIdAsync(int id, CancellationToken cancellationToken = default) =>
        Db.Enrollments.AsNoTracking().Include(e => e.Student).Include(e => e.Course)
            .FirstOrDefaultAsync(e => e.Id == id, cancellationToken);
    public Task<bool> StudentExistsAsync(int studentId, CancellationToken cancellationToken = default) =>
        Db.Students.AnyAsync(s => s.Id == studentId, cancellationToken);
    public Task<bool> CourseExistsAsync(int courseId, CancellationToken cancellationToken = default) =>
        Db.Courses.AnyAsync(c => c.Id == courseId, cancellationToken);
    public Task<bool> AlreadyEnrolledAsync(int studentId, int courseId, int? exceptId = null, CancellationToken cancellationToken = default) =>
        Db.Enrollments.AnyAsync(e => e.StudentId == studentId && e.CourseId == courseId &&
            (!exceptId.HasValue || e.Id != exceptId.Value), cancellationToken);
}

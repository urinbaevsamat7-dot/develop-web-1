using AutoMapper;
using UniversityApi.DTO.Students;
using UniversityApi.Models;
using UniversityApi.Repositories.Interfaces;

namespace UniversityApi.Services;

public interface IStudentService
{
    Task<List<StudentDto>> GetAllAsync(CancellationToken ct);
    Task<StudentDto?> GetByIdAsync(int id, CancellationToken ct);
    Task<StudentWithCoursesDto?> GetWithCoursesAsync(int id, CancellationToken ct);
    Task<(StudentDto? Value, string? Error)> CreateAsync(StudentCreateDto dto, CancellationToken ct);
    Task<(StudentDto? Value, string? Error)> UpdateAsync(int id, StudentUpdateDto dto, CancellationToken ct);
    Task<bool> DeleteAsync(int id, CancellationToken ct);
}
public sealed class StudentService(IStudentRepository repo, IMapper mapper, ILogger<StudentService> logger) : IStudentService
{
    public async Task<List<StudentDto>> GetAllAsync(CancellationToken ct) => mapper.Map<List<StudentDto>>(await repo.GetAllAsync(ct));
    public async Task<StudentDto?> GetByIdAsync(int id, CancellationToken ct) => mapper.Map<StudentDto?>(await repo.GetByIdAsync(id, ct));
    public async Task<StudentWithCoursesDto?> GetWithCoursesAsync(int id, CancellationToken ct)
    {
        var student = await repo.GetWithCoursesAsync(id, ct);
        if (student is null) return null;
        var dto = mapper.Map<StudentWithCoursesDto>(student);
        dto.Courses = student.Enrollments.Select(e => new StudentCourseDto
        { CourseId = e.CourseId, CourseName = e.Course?.Name ?? "", Grade = e.Grade, EnrollmentDate = e.EnrollmentDate }).ToList();
        return dto;
    }
    public async Task<(StudentDto? Value, string? Error)> CreateAsync(StudentCreateDto dto, CancellationToken ct)
    {
        if (await repo.EmailExistsAsync(dto.Email, null, ct)) return (null, "EMAIL_ALREADY_EXISTS");
        var entity = mapper.Map<Student>(dto);
        await repo.AddAsync(entity, ct); await repo.SaveChangesAsync(ct);
        logger.LogInformation("Created student {StudentId}", entity.Id);
        return (mapper.Map<StudentDto>(entity), null);
    }
    public async Task<(StudentDto? Value, string? Error)> UpdateAsync(int id, StudentUpdateDto dto, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(id, ct);
        if (entity is null) { logger.LogWarning("Student {StudentId} not found for update", id); return (null, "NOT_FOUND"); }
        if (await repo.EmailExistsAsync(dto.Email, id, ct)) return (null, "EMAIL_ALREADY_EXISTS");
        mapper.Map(dto, entity); repo.Update(entity); await repo.SaveChangesAsync(ct);
        logger.LogInformation("Updated student {StudentId}", id);
        return (mapper.Map<StudentDto>(entity), null);
    }
    public async Task<bool> DeleteAsync(int id, CancellationToken ct)
    {
        var entity = await repo.GetByIdAsync(id, ct);
        if (entity is null) { logger.LogWarning("Student {StudentId} not found for delete", id); return false; }
        repo.Delete(entity); await repo.SaveChangesAsync(ct); logger.LogInformation("Deleted student {StudentId}", id); return true;
    }
}
